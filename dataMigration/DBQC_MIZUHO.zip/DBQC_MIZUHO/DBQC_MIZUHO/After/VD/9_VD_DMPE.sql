HOST "md %crnt_dirty%\DBQC_REPORT\AFTER\VD"
SET PAGES 40000
SET MARKUP HTML ON
SPOOL %crnt_dirty%\DBQC_REPORT\AFTER\VD\DMPE_%CLIENT%_VD_AFTR_UPG.xls

PROMPT '********************************************************************************************'

PROMPT LOG MIGRATION  Start

SELECT SYSTIMESTAMP FROM DUAL;

PROMPT LOG MIGRATION  User

SELECT USER FROM DUAL;


PROMPT LOG MIGRATION Execution 
 SELECT PATCH_ID,DATA_MODL_ID,TBL_DDL_NME,PATCH_SEQ_NUM,DDLE_SCRIPT_CREATION_TMS,EXEC_DDL_TYP,EXEC_DDL_STMT_TXT,EXEC_DDL_APPLIED_TMS,EXEC_DDL_STAT_TYP,EXEC_DDL_ERROR_DTL_TXT,
 execution_tms,
    round((end_time - start_time) * 24, 2)           diff_hours,
    round((end_time - start_time) * 24 * 60, 2)      diff_minutes,
    round((end_time - start_time) * 24 * 60 * 60, 2) diff_seconds
    from (
SELECT PATCH_ID,DATA_MODL_ID,TBL_DDL_NME,PATCH_SEQ_NUM,DDLE_SCRIPT_CREATION_TMS,EXEC_DDL_TYP,EXEC_DDL_STMT_TXT,EXEC_DDL_APPLIED_TMS,EXEC_DDL_STAT_TYP,EXEC_DDL_ERROR_DTL_TXT,
  EXEC_DDL_APPLIED_TMS as execution_tms,
            to_date(to_char(LAG(EXEC_DDL_APPLIED_TMS)
                            OVER(
                ORDER BY
                    EXEC_DDL_APPLIED_TMS
                            ), 'yyyymmdd HH24:MI:SS'), 'yyyymmdd HH24:MI:SS')                             start_time,
            to_date(to_char(EXEC_DDL_APPLIED_TMS, 'yyyymmdd HH24:MI:SS'), 'yyyymmdd HH24:MI:SS') end_time
FROM FT_T_DMPE  ORDER BY DDLE_SCRIPT_CREATION_TMS) order by DDLE_SCRIPT_CREATION_TMS;



PROMPT LOG MIGRATION  End

SELECT SYSTIMESTAMP FROM DUAL;

SPOOL OFF
SET MARKUP HTML OFF
EXIT