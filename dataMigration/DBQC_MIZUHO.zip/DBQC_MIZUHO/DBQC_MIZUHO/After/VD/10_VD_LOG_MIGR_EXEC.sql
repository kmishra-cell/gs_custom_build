HOST "md %crnt_dirty%\DBQC_REPORT\AFTER\VD"
SET PAGES 40000
SET MARKUP HTML ON
SPOOL %crnt_dirty%\DBQC_REPORT\AFTER\VD\LOG_MIGR_EXEC_%CLIENT%_VD_AFTR_UPG.xls

PROMPT '********************************************************************************************'

PROMPT LOG MIGRATION  Start

SELECT SYSTIMESTAMP FROM DUAL;

PROMPT LOG MIGRATION  User

SELECT USER FROM DUAL;


PROMPT LOG MIGRATION Execution 

SELECT
    script_name,
    execution_script,
    execution_state,
    error_code,
    error_msg,
    execution_tms,
    round((end_time - start_time) * 24, 2)           diff_hours,
    round((end_time - start_time) * 24 * 60, 2)      diff_minutes,
    round((end_time - start_time) * 24 * 60 * 60, 2) diff_seconds
FROM
    (
        SELECT
            script_name,
            execution_script,
            execution_state,
            error_code,
            error_msg,
            execution_tms,
            to_date(to_char(LAG(execution_tms)
                            OVER(
                ORDER BY
                    execution_tms
                            ), 'yyyymmdd HH24:MI:SS'), 'yyyymmdd HH24:MI:SS')                             start_time,
            to_date(to_char(execution_tms, 'yyyymmdd HH24:MI:SS'), 'yyyymmdd HH24:MI:SS') end_time
        FROM
            ft_log_migr_exec
    )
ORDER BY
    execution_tms;



PROMPT LOG MIGRATION  End

SELECT SYSTIMESTAMP FROM DUAL;

SPOOL OFF
SET MARKUP HTML OFF
EXIT