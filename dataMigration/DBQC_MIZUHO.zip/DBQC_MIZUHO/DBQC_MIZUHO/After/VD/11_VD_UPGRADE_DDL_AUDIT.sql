HOST "md %crnt_dirty%\DBQC_REPORT\AFTER\VD"
SET PAGES 40000
SET MARKUP HTML ON
SPOOL %crnt_dirty%\DBQC_REPORT\AFTER\VD\UPGRADE_DDL_AUDIT_%CLIENT%_VD_AFTR_UPG.xls


PROMPT '********************************************************************************************'

PROMPT Upgrade DDL Audit Log start

SELECT SYSTIMESTAMP FROM DUAL;


PROMPT Upgrade DDL Audit USER

SELECT USER FROM DUAL;



PROMPT Log Upgrade DDL Audit  DROP TABLE DETAILS 


select alter_time_col,
            osuser_col,
            current_user_col,
            host_col,
            terminal_col,
            owner_col,
            type_col,
            name_col,
            sysevent_col,
            sql_executed_col  from upgrade_ddl_audit where TYPE_COL='TABLE' AND (SYSEVENT_COL ='DROP' OR UPPER(SQL_EXECUTED_COL)  LIKE '%DROP%TABLE%');

PROMPT Log Upgrade DDL Audit  RENAME TABLE DETAILS 

select alter_time_col,
            osuser_col,
            current_user_col,
            host_col,
            terminal_col,
            owner_col,
            type_col,
            name_col,
            sysevent_col,
            sql_executed_col  from upgrade_ddl_audit where TYPE_COL='TABLE' AND  SYSEVENT_COL='RENAME'  ;
			
			
PROMPT Log Upgrade DDL Audit  DROP COLUMN DETAILS 

select alter_time_col,
            osuser_col,
            current_user_col,
            host_col,
            terminal_col,
            owner_col,
            type_col,
            name_col,
            sysevent_col,
            sql_executed_col  from upgrade_ddl_audit where TYPE_COL='TABLE' AND (SYSEVENT_COL ='ALTER' AND UPPER(SQL_EXECUTED_COL) LIKE '%DROP%COLUMN%');

PROMPT Log Upgrade DDL Audit  RENAME COLUMN DETAILS 

select alter_time_col,
            osuser_col,
            current_user_col,
            host_col,
            terminal_col,
            owner_col,
            type_col,
            name_col,
            sysevent_col,
            sql_executed_col  from upgrade_ddl_audit where TYPE_COL='TABLE' AND  SYSEVENT_COL='ALTER' AND  UPPER(SQL_EXECUTED_COL) LIKE '%RENAME%' ;


PROMPT Index Creation that needs to be tuned  

PROMPT Step1 - Record Count table creation 
CREATE TABLE GS_RECORD_COUNT_AFT_UPGRADE AS 
select table_name,
  to_number(
   extractvalue(
      xmltype(
         dbms_xmlgen.getxml('select /*+ parallel (16) */ count(*) c from '||table_name))
    ,'/ROWSET/ROW/C')) as cnt
from user_tables  where IOT_NAME IS  NULL  ;

PROMPT Step2 - Index that created multiple times based on table specific record count  
SELECT A.NAME_COL,A.NO_OF_TIMES_INDEX_GOT_CREATED, D.TBL_DDL_NME, B.CNT AS TBL_RECORD_COUNT
from
(
SELECT NAME_COL,COUNT(*) NO_OF_TIMES_INDEX_GOT_CREATED
FROM UPGRADE_DDL_AUDIT WHERE TYPE_COL='INDEX' AND SYSEVENT_COL='CREATE'
GROUP BY NAME_COL HAVING COUNT(*)>1) A,
GS_RECORD_COUNT_AFT_UPGRADE B,
FT_T_TIDX C,
FT_T_TBDF D
WHERE
A.NAME_COL=C.TBL_INDEX_NME
AND C.TBL_ID=D.TBL_ID
AND D.TBL_DDL_NME = B.TABLE_NAME  and B.CNT>100000
order by 4 desc;



PROMPT Log Upgrade DDL Audit  TOP 100 Statements took considerable time 
SELECT * FROM (
SELECT * FROM (
SELECT
    alter_time_col,
    osuser_col,
    current_user_col,
    host_col,
    terminal_col,
    owner_col,
    type_col,
    name_col,
    sysevent_col,
    sql_executed_col,
    round((end_time - start_time) * 24, 2)           diff_hours,
    round((end_time - start_time) * 24 * 60, 2)      diff_minutes,
    round((end_time - start_time) * 24 * 60 * 60, 2) diff_seconds
FROM
    (
        SELECT
            alter_time_col,
            osuser_col,
            current_user_col,
            host_col,
            terminal_col,
            owner_col,
            type_col,
            name_col,
            sysevent_col,
            sql_executed_col,
            to_date(to_char(lag(alter_time_col)
                            OVER(
                ORDER BY
                    alter_time_col
                            ), 'yyyymmdd HH24:MI:SS'), 'yyyymmdd HH24:MI:SS')                          start_time     ,
            to_date(to_char(alter_time_col, 'yyyymmdd HH24:MI:SS'), 'yyyymmdd HH24:MI:SS') end_time
        FROM
            upgrade_ddl_audit
     ))
ORDER BY
    diff_minutes DESC ) WHERE ROWNUM<101 ;
	


PROMPT Log Upgrade DDL Audit  details

SELECT
    alter_time_col,
    osuser_col,
    current_user_col,
    host_col,
    terminal_col,
    owner_col,
    type_col,
    name_col,
    sysevent_col,
    sql_executed_col,
    round((end_time - start_time) * 24, 2)           diff_hours,
    round((end_time - start_time) * 24 * 60, 2)      diff_minutes,
    round((end_time - start_time) * 24 * 60 * 60, 2) diff_seconds
FROM
    (
        SELECT
            alter_time_col,
            osuser_col,
            current_user_col,
            host_col,
            terminal_col,
            owner_col,
            type_col,
            name_col,
            sysevent_col,
            sql_executed_col,
            to_date(to_char(LAG(alter_time_col)
                            OVER(
                ORDER BY
                    alter_time_col
                            ), 'yyyymmdd HH24:MI:SS'), 'yyyymmdd HH24:MI:SS')                              start_time,
            to_date(to_char(alter_time_col, 'yyyymmdd HH24:MI:SS'), 'yyyymmdd HH24:MI:SS') end_time
        FROM
            upgrade_ddl_audit
    )
ORDER BY
    alter_time_col;


PROMPT Log migration  End

SELECT SYSTIMESTAMP FROM DUAL;

SPOOL OFF
SET MARKUP HTML OFF
EXIT