HOST "md %crnt_dirty%\DBQC_REPORT\AFTER\AUDIT"
SET PAGES 40000
set verify off
SET MARKUP HTML ON
SPOOL %crnt_dirty%\DBQC_REPORT\AFTER\AUDIT\DBQC_%CLIENT%_AUDIT_AFTR_UPG.xls

PROMPT ENTER Audit Schema Name 
--ACCEPT AUDIT_SCHEMA CHAR
PROMPT Audit Schema :-  &1


PROMPT '********************************************************************************************'

PROMPT Number of tables enabled for Audit, Stage and Bitemporal

SELECT COUNT(*) FROM FT_T_TBDF WHERE   (     NVL (AUDIT_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (STAGING_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (BI_TEMPORAL_IND, 'N') = 'Y');

PROMPT '********************************************************************************************'

PROMPT Number of tables enabled for Audit 

SELECT COUNT(*) FROM FT_T_TBDF WHERE   (     NVL (AUDIT_ENABLED_IND, 'N') = 'Y' );


PROMPT '********************************************************************************************'

PROMPT  Number of tables enabled for   Stage  

SELECT COUNT(*) FROM FT_T_TBDF WHERE   (      NVL (STAGING_ENABLED_IND, 'N') = 'Y' );


PROMPT '********************************************************************************************'

PROMPT Number of tables enabled for  Bitemporal

SELECT COUNT(*) FROM FT_T_TBDF WHERE   (   NVL (BI_TEMPORAL_IND, 'N') = 'Y');


PROMPT **********************************************************************								 
PROMPT Number of tables Present in Audit schema 

SELECT COUNT(*) FROM  ALL_TABLES 
WHERE     OWNER = '&1' AND TABLE_NAME IN (SELECT TBL_DDL_NME FROM FT_T_TBDF WHERE   (     NVL (AUDIT_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (STAGING_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (BI_TEMPORAL_IND, 'N') = 'Y'));								 
								 
PROMPT **********************************************************************								 
PROMPT Table Enabled for Audit but not present in Audit Schema
SELECT TBL_DDL_NME  FROM FT_T_TBDF WHERE   (     NVL (AUDIT_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (STAGING_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (BI_TEMPORAL_IND, 'N') = 'Y')
MINUS
SELECT TABLE_NAME  FROM  ALL_TABLES 
WHERE     OWNER = '&1' AND TABLE_NAME IN (SELECT TBL_DDL_NME FROM FT_T_TBDF WHERE   (     NVL (AUDIT_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (STAGING_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (BI_TEMPORAL_IND, 'N') = 'Y'));   
								 
PROMPT **********************************************************************
PROMPT List of tables which are having DDL Metadata differences in GC schema.

SELECT *
  FROM (SELECT TBL_DDL_NME,
               DECODE (CDC_PKG.CHK_DDL_META_DIFF (TBL_DDL_NME), 0, 'Y', 'N')
                  MISMATCH
          FROM FT_T_TBDF
         WHERE NVL (AUDIT_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (STAGING_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (BI_TEMPORAL_IND, 'N') = 'Y')
 WHERE MISMATCH = 'Y';


PROMPT **********************************************************************								 
PROMPT GC Metadata Comparison with Audit Metadata

SELECT B.TBL_DDL_NME,
       A.COL_NME,
       DECODE (A.DDL_DATA_TYP,
               'INTEGER', 'NUMBER',
               'TIMESTAMP', 'TIMESTAMP(6)',
               A.DDL_DATA_TYP)
          DATA_TYPE
  FROM FT_T_CLDF A,
       FT_T_TBDF B,
       FT_T_FLDF C,
       FT_T_FCDF D
WHERE     A.TBL_ID = B.TBL_ID
       AND A.FLD_ID = C.FLD_ID
       AND C.FLD_DATA_CL_ID = D.FLD_DATA_CL_ID
       AND B.TBL_DDL_NME NOT LIKE 'FT_V%'
       AND B.TBL_DDL_NME NOT LIKE '%STATS%'
       AND NVL (A.VIRTUAL_COL_IND, 'N') = 'N'
       AND (   B.AUDIT_ENABLED_IND = 'Y'
            OR B.STAGING_ENABLED_IND = 'Y'
            OR B.BI_TEMPORAL_IND = 'Y')
       AND B.TBL_DDL_NME != 'FT_O_ADEL'
MINUS
SELECT A.AUDIT_TBL_DDL_NME, B.COL_NME, B.DDL_DATA_TYP DATA_TYPE
  FROM FT_T_ASTB A, FT_T_ASTC B
WHERE A.ASTB_OID = B.ASTB_OID
ORDER BY 1, 2, 3;

PROMPT **********************************************************************
PROMPT Audit Metadata Comparison with GC Metadata

SELECT A.AUDIT_TBL_DDL_NME, B.COL_NME, B.DDL_DATA_TYP DATA_TYPE
  FROM FT_T_ASTB A, FT_T_ASTC B
WHERE     A.ASTB_OID = B.ASTB_OID
       AND TRIM (B.COL_NME) NOT IN
              ('TRN_CRTE_TMSMP',
               'AUDIT_KNOWLEDGE_TMS',
               'AUDT_CRTE_TME',
               'AUDT_SEQ_NUM',
               'DB_OPER_TYP',
               'GC_COMMIT_TIMESTAMP',
               'ORA_TRN_ID',
               'ROW_SCN')
MINUS
SELECT B.TBL_DDL_NME,
       A.COL_NME,
      DECODE (A.DDL_DATA_TYP,
               'INTEGER', 'NUMBER',
               'TIMESTAMP', 'TIMESTAMP(6)',
               A.DDL_DATA_TYP)
          DATA_TYPE
  FROM FT_T_CLDF A,
       FT_T_TBDF B,
       FT_T_FLDF C,
       FT_T_FCDF D
WHERE     A.TBL_ID = B.TBL_ID
       AND A.FLD_ID = C.FLD_ID
       AND C.FLD_DATA_CL_ID = D.FLD_DATA_CL_ID
       AND B.TBL_DDL_NME NOT LIKE 'FT_V%'
       AND B.TBL_DDL_NME NOT LIKE '%STATS%'
       AND NVL (A.VIRTUAL_COL_IND, 'N') = 'N'
       AND (   B.AUDIT_ENABLED_IND = 'Y'
            OR B.STAGING_ENABLED_IND = 'Y'
            OR B.BI_TEMPORAL_IND = 'Y')
       AND B.TBL_DDL_NME != 'FT_O_ADEL'
       order by 1,2,3;

PROMPT **********************************************************************
PROMPT GC Metadata Comparison VS Audit Metadata Comparison 

  SELECT GC.TBL_DDL_NME,
         GC.COL_NME,
         GC.DATA_TYPE,
         AUDT.AUDIT_TBL_DDL_NME,
         AUDT.COL_NME AUDIT_COL_NME,
         AUDT.DATA_TYPE  AUDIT_DATA_TYPE
    FROM (SELECT B.TBL_DDL_NME,
                 A.COL_NME,
                 DECODE (A.DDL_DATA_TYP,
                         'INTEGER', 'NUMBER',
                         'TIMESTAMP', 'TIMESTAMP(6)',
                         A.DDL_DATA_TYP)
                    DATA_TYPE
            FROM FT_T_CLDF A,
                 FT_T_TBDF B,
                 FT_T_FLDF C,
                 FT_T_FCDF D
           WHERE     A.TBL_ID = B.TBL_ID
                 AND A.FLD_ID = C.FLD_ID
                 AND C.FLD_DATA_CL_ID = D.FLD_DATA_CL_ID
                 AND B.TBL_DDL_NME NOT LIKE 'FT_V%'
                 AND B.TBL_DDL_NME NOT LIKE '%STATS%'
                 AND NVL (A.VIRTUAL_COL_IND, 'N') = 'N'
                 AND (   B.AUDIT_ENABLED_IND = 'Y'
                      OR B.STAGING_ENABLED_IND = 'Y'
                      OR B.BI_TEMPORAL_IND = 'Y')
                 AND B.TBL_DDL_NME != 'FT_O_ADEL'
          MINUS
          SELECT A.AUDIT_TBL_DDL_NME, B.COL_NME, B.DDL_DATA_TYP DATA_TYPE
            FROM FT_T_ASTB A, FT_T_ASTC B
           WHERE A.ASTB_OID = B.ASTB_OID) GC
         FULL OUTER JOIN
         (SELECT A.AUDIT_TBL_DDL_NME, B.COL_NME, B.DDL_DATA_TYP DATA_TYPE
            FROM FT_T_ASTB A, FT_T_ASTC B
           WHERE     A.ASTB_OID = B.ASTB_OID
                 AND TRIM (B.COL_NME) NOT IN
                        ('TRN_CRTE_TMSMP',
                         'AUDIT_KNOWLEDGE_TMS',
                         'AUDT_CRTE_TME',
                         'AUDT_SEQ_NUM',
                         'DB_OPER_TYP',
                         'GC_COMMIT_TIMESTAMP',
                         'ORA_TRN_ID',
                         'ROW_SCN')
          MINUS
          SELECT B.TBL_DDL_NME,
                 A.COL_NME,
                 DECODE (A.DDL_DATA_TYP,
                         'INTEGER', 'NUMBER',
                         'TIMESTAMP', 'TIMESTAMP(6)',
                         A.DDL_DATA_TYP)
                    DATA_TYPE
            FROM FT_T_CLDF A,
                 FT_T_TBDF B,
                 FT_T_FLDF C,
                 FT_T_FCDF D
           WHERE     A.TBL_ID = B.TBL_ID
                 AND A.FLD_ID = C.FLD_ID
                 AND C.FLD_DATA_CL_ID = D.FLD_DATA_CL_ID
                 AND B.TBL_DDL_NME NOT LIKE 'FT_V%'
                 AND B.TBL_DDL_NME NOT LIKE '%STATS%'
                 AND NVL (A.VIRTUAL_COL_IND, 'N') = 'N'
                 AND (   B.AUDIT_ENABLED_IND = 'Y'
                      OR B.STAGING_ENABLED_IND = 'Y'
                      OR B.BI_TEMPORAL_IND = 'Y')
                 AND B.TBL_DDL_NME != 'FT_O_ADEL') AUDT
            ON     GC.TBL_DDL_NME = AUDT.AUDIT_TBL_DDL_NME
               AND GC.COL_NME = AUDT.COL_NME
ORDER BY 1,
         2,
         3,
         4,
         5,
         6;

PROMPT **********************************************************************
PROMPT GC DDL Comparison with Audit DDL

SELECT TABLE_NAME,
       COLUMN_NAME,
       DECODE (
          DATA_TYPE,
          'DATE', DATA_TYPE,
          'XMLTYPE', DATA_TYPE,
          'CLOB', DATA_TYPE,
          'BLOB', DATA_TYPE,
          'TIMESTAMP(6)', DATA_TYPE,
          'NUMBER',    DATA_TYPE
                    || DECODE (
                          DATA_PRECISION,
                          '', '',
                             '('
                          || DATA_PRECISION
                          || DECODE (DATA_SCALE, 0, '', ',' || DATA_SCALE)
                          || ')'),
           DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
  FROM  USER_TAB_COLUMNS
WHERE TABLE_NAME IN
          (SELECT TBL_DDL_NME
             FROM FT_T_TBDF
            WHERE (   AUDIT_ENABLED_IND = 'Y'
                   OR STAGING_ENABLED_IND = 'Y'
                   OR BI_TEMPORAL_IND = 'Y')) AND TABLE_NAME NOT IN ('FT_O_ADEL')
MINUS
SELECT TABLE_NAME,
       COLUMN_NAME,
       DECODE (
          DATA_TYPE,
          'DATE', DATA_TYPE,
          'XMLTYPE', DATA_TYPE,
          'CLOB', DATA_TYPE,
          'BLOB', DATA_TYPE,
          'TIMESTAMP(6)', DATA_TYPE,
          'NUMBER',    DATA_TYPE
                    || DECODE (
                          DATA_PRECISION,
                          '', '',
                             '('
                          || DATA_PRECISION
                          || DECODE (DATA_SCALE, 0, '', ',' || DATA_SCALE)
                          || ')'),
           DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
  FROM  ALL_TAB_COLUMNS
WHERE     OWNER = '&1'
       AND TABLE_NAME IN
              (SELECT TBL_DDL_NME
                 FROM FT_T_TBDF
                WHERE (   AUDIT_ENABLED_IND = 'Y'
                       OR STAGING_ENABLED_IND = 'Y'
                       OR BI_TEMPORAL_IND = 'Y'))
					   ORDER BY 1,2;


PROMPT **********************************************************************
PROMPT Audit DDL Comparison with GC DDL

SELECT TABLE_NAME,
       COLUMN_NAME,
       DECODE (
          DATA_TYPE,
          'DATE', DATA_TYPE,
          'XMLTYPE', DATA_TYPE,
          'CLOB', DATA_TYPE,
          'BLOB', DATA_TYPE,
          'TIMESTAMP(6)', DATA_TYPE,
          'NUMBER',    DATA_TYPE
                    || DECODE (
                          DATA_PRECISION,
                          '', '',
                             '('
                          || DATA_PRECISION
                          || DECODE (DATA_SCALE, 0, '', ',' || DATA_SCALE)
                          || ')'),
           DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
  FROM  ALL_TAB_COLUMNS
WHERE     OWNER = '&1'
       AND TABLE_NAME IN
              (SELECT TBL_DDL_NME
                 FROM FT_T_TBDF
                WHERE (   AUDIT_ENABLED_IND = 'Y'
                       OR STAGING_ENABLED_IND = 'Y'
                       OR BI_TEMPORAL_IND = 'Y'))
       AND COLUMN_NAME NOT IN
              ('TRN_CRTE_TMSMP',
               'AUDIT_KNOWLEDGE_TMS',
               'AUDT_CRTE_TME',
               'AUDT_SEQ_NUM',
               'DB_OPER_TYP',
               'GC_COMMIT_TIMESTAMP',
               'ORA_TRN_ID',
               'ROW_SCN') AND TABLE_NAME NOT IN ('FT_O_ADEL')
MINUS
SELECT TABLE_NAME,
       COLUMN_NAME,
       DECODE (
          DATA_TYPE,
          'DATE', DATA_TYPE,
          'XMLTYPE', DATA_TYPE,
          'CLOB', DATA_TYPE,
          'BLOB', DATA_TYPE,
          'TIMESTAMP(6)', DATA_TYPE,
          'NUMBER',    DATA_TYPE
                    || DECODE (
                          DATA_PRECISION,
                          '', '',
                             '('
                          || DATA_PRECISION
                          || DECODE (DATA_SCALE, 0, '', ',' || DATA_SCALE)
                          || ')'),
           DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
  FROM  USER_TAB_COLUMNS
WHERE TABLE_NAME IN
          (SELECT TBL_DDL_NME
             FROM FT_T_TBDF
            WHERE (   AUDIT_ENABLED_IND = 'Y'
                   OR STAGING_ENABLED_IND = 'Y'
                   OR BI_TEMPORAL_IND = 'Y'))
ORDER BY 1, 2, 3;


PROMPT **********************************************************************
PROMPT GC VS AUDIT DDL Comparison
  
  SELECT GC.TABLE_NAME,
         GC.COLUMN_NAME,
         GC.DATA_TYPE,
         AUDT.TABLE_NAME,
         AUDT.COLUMN_NAME,
         AUDT.DATA_TYPE
    FROM (SELECT TABLE_NAME,
                 COLUMN_NAME,
                 DECODE (
                    DATA_TYPE,
                    'DATE', DATA_TYPE,
                    'XMLTYPE', DATA_TYPE,
                    'CLOB', DATA_TYPE,
                    'BLOB', DATA_TYPE,
                    'TIMESTAMP(6)', DATA_TYPE,
                    'NUMBER',    DATA_TYPE
                              || DECODE (
                                    DATA_PRECISION,
                                    '', '',
                                       '('
                                    || DATA_PRECISION
                                    || DECODE (DATA_SCALE,
                                               0, '',
                                               ',' || DATA_SCALE)
                                    || ')'),
                     DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
            FROM  USER_TAB_COLUMNS
           WHERE     TABLE_NAME IN
                        (SELECT TBL_DDL_NME
                           FROM FT_T_TBDF
                          WHERE (   NVL (AUDIT_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (STAGING_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (BI_TEMPORAL_IND, 'N') = 'Y'))
                 AND TABLE_NAME NOT IN ('FT_O_ADEL')
          MINUS
          SELECT TABLE_NAME,
                 COLUMN_NAME,
                 DECODE (
                    DATA_TYPE,
                    'DATE', DATA_TYPE,
                    'XMLTYPE', DATA_TYPE,
                    'CLOB', DATA_TYPE,
                    'BLOB', DATA_TYPE,
                    'TIMESTAMP(6)', DATA_TYPE,
                    'NUMBER',    DATA_TYPE
                              || DECODE (
                                    DATA_PRECISION,
                                    '', '',
                                       '('
                                    || DATA_PRECISION
                                    || DECODE (DATA_SCALE,
                                               0, '',
                                               ',' || DATA_SCALE)
                                    || ')'),
                     DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
            FROM  ALL_TAB_COLUMNS
           WHERE     OWNER = '&1'
                 AND TABLE_NAME IN
                        (SELECT TBL_DDL_NME
                           FROM FT_T_TBDF
                          WHERE (   NVL (AUDIT_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (STAGING_ENABLED_IND, 'N') = 'Y'
                                 OR NVL (BI_TEMPORAL_IND, 'N') = 'Y'))) GC
         FULL OUTER JOIN
         (SELECT TABLE_NAME,
                 COLUMN_NAME,
                 DECODE (
                    DATA_TYPE,
                    'DATE', DATA_TYPE,
                    'XMLTYPE', DATA_TYPE,
                    'CLOB', DATA_TYPE,
                    'BLOB', DATA_TYPE,
                    'TIMESTAMP(6)', DATA_TYPE,
                    'NUMBER',    DATA_TYPE
                              || DECODE (
                                    DATA_PRECISION,
                                    '', '',
                                       '('
                                    || DATA_PRECISION
                                    || DECODE (DATA_SCALE,
                                               0, '',
                                               ',' || DATA_SCALE)
                                    || ')'),
                     DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
            FROM  ALL_TAB_COLUMNS
           WHERE     OWNER = '&1'
                 AND TABLE_NAME IN
                        (SELECT TBL_DDL_NME
                           FROM FT_T_TBDF
                          WHERE (   AUDIT_ENABLED_IND = 'Y'
                                 OR STAGING_ENABLED_IND = 'Y'
                                 OR BI_TEMPORAL_IND = 'Y'))
                 AND COLUMN_NAME NOT IN
                        ('TRN_CRTE_TMSMP',
                         'AUDIT_KNOWLEDGE_TMS',
                         'AUDT_CRTE_TME',
                         'AUDT_SEQ_NUM',
                         'DB_OPER_TYP',
                         'GC_COMMIT_TIMESTAMP',
                         'ORA_TRN_ID',
                         'ROW_SCN')
                 AND TABLE_NAME NOT IN ('FT_O_ADEL')
          MINUS
          SELECT TABLE_NAME,
                 COLUMN_NAME,
                 DECODE (
                    DATA_TYPE,
                    'DATE', DATA_TYPE,
                    'XMLTYPE', DATA_TYPE,
                    'CLOB', DATA_TYPE,
                    'BLOB', DATA_TYPE,
                    'TIMESTAMP(6)', DATA_TYPE,
                    'NUMBER',    DATA_TYPE
                              || DECODE (
                                    DATA_PRECISION,
                                    '', '',
                                       '('
                                    || DATA_PRECISION
                                    || DECODE (DATA_SCALE,
                                               0, '',
                                               ',' || DATA_SCALE)
                                    || ')'),
                     DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
            FROM  USER_TAB_COLUMNS
           WHERE TABLE_NAME IN
                    (SELECT TBL_DDL_NME
                       FROM FT_T_TBDF
                      WHERE (   AUDIT_ENABLED_IND = 'Y'
                             OR STAGING_ENABLED_IND = 'Y'
                             OR BI_TEMPORAL_IND = 'Y'))) AUDT
            ON     GC.TABLE_NAME = AUDT.TABLE_NAME
               AND GC.COLUMN_NAME = AUDT.COLUMN_NAME
ORDER BY 1,
         2,
         3,
         4,
         5,
         6;


PROMPT **********************************************************************
PROMPT AUDIT DDL VS AUDIT META Comparison

SELECT AUDT_DDL.TABLE_NAME,
       AUDT_DDL.COLUMN_NAME,
       AUDT_DDL.DATA_TYPE,
       AUDT_META.AUDIT_TBL_DDL_NME,
       AUDT_META.COL_NME,
       AUDT_META.DATA_TYPE
  FROM (SELECT TABLE_NAME,
               COLUMN_NAME,
               DECODE (
                  DATA_TYPE,
                  'DATE', DATA_TYPE,
                  'XMLTYPE', DATA_TYPE,
                  'CLOB', DATA_TYPE,
                  'BLOB', DATA_TYPE,
                  'TIMESTAMP(6)', DATA_TYPE,
                  'NUMBER',    DATA_TYPE
                            || DECODE (
                                  DATA_PRECISION,
                                  '', '',
                                     '('
                                  || DATA_PRECISION
                                  || DECODE (DATA_SCALE,
                                             0, '',
                                             ',' || DATA_SCALE)
                                  || ')'),
 DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
          FROM ALL_TAB_COLUMNS
         WHERE     OWNER = '&1'
               AND TABLE_NAME IN
                      (SELECT TBL_DDL_NME
                         FROM FT_T_TBDF
                        WHERE (   AUDIT_ENABLED_IND = 'Y'
                               OR STAGING_ENABLED_IND = 'Y' OR BI_TEMPORAL_IND = 'Y' ))
               AND COLUMN_NAME NOT IN
                      ('TRN_CRTE_TMSMP',
                       'AUDIT_KNOWLEDGE_TMS',
                       'AUDT_CRTE_TME',
                       'AUDT_SEQ_NUM',
                       'DB_OPER_TYP',
                       'GC_COMMIT_TIMESTAMP',
                       'ORA_TRN_ID',
                       'ROW_SCN')
               AND TABLE_NAME NOT IN ('FT_O_ADEL')
        MINUS
        SELECT A.AUDIT_TBL_DDL_NME, B.COL_NME, B.DDL_DATA_TYP DATA_TYPE
          FROM FT_T_ASTB A, FT_T_ASTC B
         WHERE     A.ASTB_OID = B.ASTB_OID
               AND TRIM (B.COL_NME) NOT IN
                      ('TRN_CRTE_TMSMP',
                       'AUDIT_KNOWLEDGE_TMS',
                       'AUDT_CRTE_TME',
                       'AUDT_SEQ_NUM',
                       'DB_OPER_TYP',
                       'GC_COMMIT_TIMESTAMP',
                       'ORA_TRN_ID',
                       'ROW_SCN')) AUDT_DDL
       FULL OUTER JOIN
       (SELECT A.AUDIT_TBL_DDL_NME, B.COL_NME, B.DDL_DATA_TYP DATA_TYPE
          FROM FT_T_ASTB A, FT_T_ASTC B
         WHERE     A.ASTB_OID = B.ASTB_OID
               AND TRIM (B.COL_NME) NOT IN
                      ('TRN_CRTE_TMSMP',
                       'AUDIT_KNOWLEDGE_TMS',
                       'AUDT_CRTE_TME',
                       'AUDT_SEQ_NUM',
                       'DB_OPER_TYP',
                       'GC_COMMIT_TIMESTAMP',
                       'ORA_TRN_ID',
                       'ROW_SCN')
        MINUS
        SELECT TABLE_NAME,
               COLUMN_NAME,
               DECODE (
                  DATA_TYPE,
                  'DATE', DATA_TYPE,
                  'XMLTYPE', DATA_TYPE,
                  'CLOB', DATA_TYPE,
                  'BLOB', DATA_TYPE,
                  'TIMESTAMP(6)', DATA_TYPE,
                  'NUMBER',    DATA_TYPE
                            || DECODE (
                                  DATA_PRECISION,
                                  '', '',
                                     '('
                                  || DATA_PRECISION
                                  || DECODE (DATA_SCALE,
                                             0, '',
                                             ',' || DATA_SCALE)
                                  || ')'),
					DATA_TYPE
					|| '('
					|| DECODE (CHAR_USED,
					'B', DATA_LENGTH,
					'C', CHAR_LENGTH)
					|| ')')
				AS DATA_TYPE 
          FROM ALL_TAB_COLUMNS
         WHERE     OWNER = '&1'
               AND TABLE_NAME IN
                      (SELECT TBL_DDL_NME
                         FROM FT_T_TBDF
                        WHERE (   AUDIT_ENABLED_IND = 'Y'
                               OR STAGING_ENABLED_IND = 'Y' OR BI_TEMPORAL_IND = 'Y'))
               AND COLUMN_NAME NOT IN
                      ('TRN_CRTE_TMSMP',
                       'AUDIT_KNOWLEDGE_TMS',
                       'AUDT_CRTE_TME',
                       'AUDT_SEQ_NUM',
                       'DB_OPER_TYP',
                       'GC_COMMIT_TIMESTAMP',
                       'ORA_TRN_ID',
                       'ROW_SCN')
               AND TABLE_NAME NOT IN ('FT_O_ADEL')) AUDT_META
          ON     AUDT_DDL.TABLE_NAME = AUDT_META.AUDIT_TBL_DDL_NME
             AND AUDT_DDL.COLUMN_NAME = AUDT_META.COL_NME;


PROMPT **********************************************************************
PROMPT Triggers in Valid state	 
SELECT COUNT(*) FROM USER_OBJECTS WHERE OBJECT_TYPE='TRIGGER' AND OBJECT_NAME LIKE '%CDC%' AND STATUS='VALID';

PROMPT **********************************************************************		 
PROMPT Triggers in Invalid state	 
SELECT OBJECT_NAME, OBJECT_TYPE FROM USER_OBJECTS WHERE OBJECT_TYPE='TRIGGER' AND OBJECT_NAME LIKE '%CDC%' AND STATUS!='VALID';

PROMPT **********************************************************************
PROMPT Triggers in Enabled state	 
SELECT COUNT(*) FROM USER_TRIGGERS  WHERE  STATUS='ENABLED' AND TRIGGER_NAME LIKE '%CDC%';

PROMPT **********************************************************************
PROMPT Triggers in Disabled state	 
SELECT TRIGGER_NAME, STATUS FROM USER_TRIGGERS  WHERE  STATUS!='ENABLED' AND TRIGGER_NAME LIKE '%CDC%';

PROMPT **********************************************************************
PROMPT Triggers errors
SELECT * FROM USER_ERRORS WHERE NAME IN (SELECT OBJECT_NAME FROM USER_OBJECTS WHERE OBJECT_TYPE='TRIGGER' AND OBJECT_NAME LIKE '%CDC%' AND STATUS!='VALID');


PROMPT **********************************************************************
PROMPT Checking for valid triggers...
SELECT CASE
          WHEN COUNTOFTABLESCONFIGURED = COUNTOFTRIGGERS
          THEN
             'All Triggers Configured succesfully'
          ELSE
             'Some Triggers are missing contact GS Team'
       END
          RESULT
  FROM (SELECT (SELECT COUNT (1)
                  FROM FT_T_TBDF
                 WHERE STAGING_ENABLED_IND = 'Y' OR AUDIT_ENABLED_IND = 'Y')
                  COUNTOFTABLESCONFIGURED,
               (SELECT COUNT (1)
                  FROM USER_OBJECTS
                 WHERE OBJECT_NAME LIKE '%CDC_TRIGGER' AND STATUS = 'VALID')
                  COUNTOFTRIGGERS
          FROM DUAL);
PROMPT Expected Output : All Triggers Configured succesfully

 

SPOOL OFF
SET MARKUP HTML OFF

EXIT