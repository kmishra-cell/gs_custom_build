HOST "md %crnt_dirty%\DBQC_REPORT\AFTER\REPO"
SET PAGES 40000
SET MARKUP HTML ON
SPOOL %crnt_dirty%\DBQC_REPORT\AFTER\REPO\REPO_%CLIENT%_REPORT_AFTR_UPG.xls

PROMPT ENTER Repo Schema Name 
PROMPT Repo Schema :-  &1


PROMPT '********************************************************************************************'


PROMPT Start - Schema Name and date
SELECT USER, TO_CHAR(SYSDATE,'YYYYMMDD HH:MI:SS') DATETIME FROM DUAL;


PROMPT  Repo Query1 

SELECT   DJOB_ID,
           DEPLOY_JOB_NME,
        --   DEPLOY_JOB_DESC,
           EXEC_STAT_TYP,
          -- DEPLOY_USR_NME,
           START_TMS,
           END_TMS,
           TO_CHAR (START_TMS, 'yyyymmdd hh:mi:ss'),
           TO_CHAR (END_TMS, 'yyyymmdd hh:mi:ss'),
           ROUND((END_TMS - START_TMS)*24,2) DIFF_HOURS,
           ROUND((END_TMS - START_TMS)*24*60,2) DIFF_MINUTES,
            ROUND((END_TMS - START_TMS)*24*60*60,2) DIFF_SECONDS,
           UNINSTALL_IND
    FROM   &1 .ft_d_djob
   WHERE   START_TMS > SYSDATE - 60
ORDER BY   start_tms;

PROMPT  Repo Query2

SELECT   DEPLOY_PKG_NME,
           djob.djob_id,
           djob.DEPLOY_JOB_NME,
          DTASK.SEQ_NUM task_number_in_pd,
           TSKD.SEQ_NUM ,
           DTASK.TASK_TYPE,
           dtask.task_nme,
           TSKD.FILE_NAME,
           tskd.EXEC_STAT_TYP,
           tskd.output,
           dtask.START_TMS,
           dtask.END_TMS,
           TO_CHAR (dtask.START_TMS, 'yyyymmdd hh:mi:ss'),
           TO_CHAR (dtask.END_TMS, 'yyyymmdd hh:mi:ss'),
           ROUND((dtask.END_TMS - dtask.START_TMS)*24,2) DIFF_HOURS,
           ROUND((dtask.END_TMS - dtask.START_TMS)*24*60,2) DIFF_MINUTES,
            ROUND((dtask.END_TMS - dtask.START_TMS)*24*60*60,2) DIFF_SECONDS
    FROM    &1 .ft_d_tskd tskd,
            &1 .ft_d_task dtask,
            &1 .ft_d_djob djob,
            &1 .ft_d_pckg pckg
   WHERE       tskd.task_id = dtask.task_id
           AND djob.djob_id = dtask.djob_id
           AND pckg.pckg_id = djob.pckg_id 
           and djob.START_TMS > SYSDATE - 60
         --   and djob.DJOB_ID=''
   Order by 1,dtask.SEQ_NUM, dtask.START_TMS;

SPOOL OFF
SET MARKUP HTML OFF
EXIT