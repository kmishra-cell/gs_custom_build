import os, sys, shutil, re, subprocess, shlex, configparser, glob
from datetime import datetime
import zipfile, platform
from urllib.parse import urlparse
import psycopg2
import base64

global baseDir
baseDir = os.getcwd() # Get the current working dir

try:   
	properties_file_to_use = sys.argv[1]
	print("User provided the property file using that file for installation")
	print("Property file is  -----> " + properties_file_to_use)
except IndexError:
	properties_file_to_use = baseDir + os.sep + '..' + os.sep + "SchemaDetails.Properties"
	print("User not provided the property file, taking property file from GEM")
	print("Property file is  -----> " + properties_file_to_use)

config = configparser.RawConfigParser()
config.read(properties_file_to_use)

def create_decode_password(encodepassword):
	decoded_password		=	encodepassword.encode()
	decoded_password_bytes	=	base64.b64decode(decoded_password)
	decoded_password_string	=	decoded_password_bytes.decode()
	return decoded_password_string.replace('Golden$ource2!2!','')


pg_gc_schema 					= config.get('SCHEMAS', 'GC_NAME')
pg_vd_schema 					= config.get('SCHEMAS', 'VD_NAME')
pg_au_schema 					= config.get('SCHEMAS', 'AU_NAME')
pg_gc_schema_passwd_encoded 	= config.get('SCHEMAS', 'GC_PASSWD')
pg_vd_schema_passwd_encoded		= config.get('SCHEMAS', 'VD_PASSWD')
pg_au_schema_passwd_encoded		= config.get('SCHEMAS', 'AU_PASSWD')
pg_db_gc_url					= config.get('DATABASE', 'DATABASE_URL_GC').replace('jdbc:','')
pg_db_vd_url					= config.get('DATABASE', 'DATABASE_URL_VD').replace('jdbc:','')

pg_db_gc_details 	= urlparse(pg_db_gc_url)
pg_db_gc_database 	= pg_db_gc_details.path[1:]
pg_db_gc_hostname 	= pg_db_gc_details.hostname
pg_db_gc_port 		= pg_db_gc_details.port
print("Postgres GC Database Name is --------------> " + pg_db_gc_database)
print("Postgres GC Database Host is --------------> " + pg_db_gc_hostname)
print("Postgres GC Database Port is --------------> " + str(pg_db_gc_port))

pg_db_vd_details 	= urlparse(pg_db_vd_url)
pg_db_vd_database 	= pg_db_vd_details.path[1:]
pg_db_vd_hostname 	= pg_db_vd_details.hostname
pg_db_vd_port 		= pg_db_vd_details.port
print("Postgres VDDB Database Name is --------------> " + pg_db_gc_database)
print("Postgres VDDB Database Host is --------------> " + pg_db_gc_hostname)
print("Postgres VDDB Database Port is --------------> " + str(pg_db_gc_port))

pg_gc_schema_passwd 			= create_decode_password(pg_gc_schema_passwd_encoded)
pg_vd_schema_passwd 			= create_decode_password(pg_vd_schema_passwd_encoded)
pg_au_schema_passwd 			= create_decode_password(pg_au_schema_passwd_encoded)

pg_migrator_file 			= baseDir + os.sep + "bin" + os.sep + "pg_migrator.py"
pg_migrator_template 		= baseDir + os.sep + "templates" + os.sep + "pg_migrator.py.template"
run_data_copy_file 			= baseDir + os.sep + "bin" + os.sep + "run-datacopy.sh"
run_data_copy_template 		= baseDir + os.sep + "templates" + os.sep + "run-datacopy.sh.template"
run_data_comp_file 			= baseDir + os.sep + "bin" + os.sep + "run-datacompare.sh"
run_data_comp_template 		= baseDir + os.sep + "templates" + os.sep + "run-datacompare.sh.template"
rep_db_conf_file 			= baseDir + os.sep + "conf" + os.sep + "replicadb.conf"
rep_db_conf_template 		= baseDir + os.sep + "templates" + os.sep + "replicadb.conf.template"

ora_schema_name 	= input("Please Enter Oracle Schema to copy (GC/VDDB/AU): ")
ora_db_host 		= input("Please Enter Oracle Schema Database Host: ")
ora_db_port 		= input("Please Enter Oracle Schema Database Port: ")
ora_db_service 		= input("Please Enter Oracle Schema Database Service: ")
ora_schema 			= input("Please Enter Oracle Schema Name: ")
ora_schema_passwd 	= input("Please Enter Oracle Schema Password: ")

print("")
print("Schema to migrate ---> " + ora_schema_name)
print("")
print("")
print("Schema Database Host is ---> " + ora_db_host)
print("")
print("")
print("Schema Database Port is ---> " + ora_db_port)
print("")
print("Schema Database Service is ---> " + ora_db_service)
print("")
print("")
print("Schema Name is ---> " + ora_schema)
print("")
print("")
print("Schema password is ---> " + ora_schema_passwd)
print("")

confirmation = input("Please confirm above Oracle details (yes/no): ")
if(confirmation == 'yes'):
	print("Thanks for confirming, now starting the migration")
else:
	print("please enter the correct details again.")
	sys.exit(1)

def del_files(FileLocation):
	print("Removing existing ---> " + FileLocation)
	os.remove(FileLocation)
	return
if os.path.isfile(pg_migrator_file) is True:
	del_files(pg_migrator_file)
	print("")
else:
	print(pg_migrator_file + " is not exist")
	print("")
if os.path.isfile(run_data_copy_file) is True:
	del_files(run_data_copy_file)
	print("")
else:
	print(run_data_copy_file + " is not exist")
	print("")
if os.path.isfile(run_data_comp_file) is True:
	del_files(run_data_comp_file)
	print("")
else:
	print(run_data_comp_file + " is not exist")
	print("")
if os.path.isfile(rep_db_conf_file) is True:
	del_files(rep_db_conf_file)
	print("")
else:
	print(rep_db_conf_file + " is not exist")
	print("")

shutil.copy(pg_migrator_template, pg_migrator_file)
shutil.copy(run_data_copy_template, run_data_copy_file)
shutil.copy(run_data_comp_template, run_data_comp_file)
shutil.copy(rep_db_conf_template, rep_db_conf_file)

migrator_file 		= open(pg_migrator_file, 'r').read()
new_migrator_file 	= migrator_file.replace('@@PG_GC_USER@@',pg_gc_schema).replace('@@PG_GC_USER_PASSWD@@',pg_gc_schema_passwd).replace('@@PG_VD_USER@@',pg_vd_schema).replace('@@PG_VD_USER_PASSWD@@',pg_vd_schema_passwd).replace('@@PG_GC_DB_HOST@@',pg_db_gc_hostname).replace('@@PG_GC_DB_SERVICE@@',pg_db_gc_database).replace('@@PG_GC_DB_PORT@@',str(pg_db_gc_port)).replace('@@PG_VD_DB_HOST@@',pg_db_vd_hostname).replace('@@PG_VD_DB_SERVICE@@',pg_db_vd_database).replace('@@PG_VD_DB_PORT@@',str(pg_db_vd_port))
with open(pg_migrator_file, 'w') as file:
	file.write(new_migrator_file)

data_copy_file 		= open(run_data_copy_file, 'r').read()
new_data_copy_file 	= data_copy_file.replace('@@MIGRATION_HOME@@',baseDir)
with open(run_data_copy_file, 'w') as file:
	file.write(new_data_copy_file)
	
data_comp_file 		= open(run_data_comp_file, 'r').read()
new_data_comp_file 	= data_comp_file.replace('@@MIGRATION_HOME@@',baseDir)
with open(run_data_comp_file, 'w') as file:
	file.write(new_data_comp_file)
if (ora_schema_name == 'GC'):
	print("Doing for GC")
	db_conf_file 		= open(rep_db_conf_file, 'r').read()
	new_db_conf_file 	= db_conf_file.replace('@@PG_USER@@',pg_gc_schema).replace('@@PG_USER_PASSWD@@',pg_gc_schema_passwd).replace('@@PG_DB_HOST@@',pg_db_gc_hostname).replace('@@PG_DB_SERVICE@@',pg_db_gc_database).replace('@@PG_DB_PORT@@',str(pg_db_gc_port)).replace('@@ORA_USER@@',ora_schema).replace('@@ORA_USER_PASSWD@@',ora_schema_passwd).replace('@@DB_ORA_HOST@@',ora_db_host).replace('@@DB_ORA_SERVICE@@',ora_db_service).replace('@@DB_ORA_PORT@@',str(ora_db_port))
	with open(rep_db_conf_file, 'w') as file:
		file.write(new_db_conf_file)
if (ora_schema_name == 'VDDB'):
	print("Doing for VDDB")
	db_conf_file 		= open(rep_db_conf_file, 'r').read()
	new_db_conf_file 	= db_conf_file.replace('@@PG_USER@@',pg_vd_schema).replace('@@PG_USER_PASSWD@@',pg_vd_schema_passwd).replace('@@PG_DB_HOST@@',pg_db_vd_hostname).replace('@@PG_DB_SERVICE@@',pg_db_vd_database).replace('@@PG_DB_PORT@@',str(pg_db_vd_port)).replace('@@ORA_USER@@',ora_schema).replace('@@ORA_USER_PASSWD@@',ora_schema_passwd).replace('@@DB_ORA_HOST@@',ora_db_host).replace('@@DB_ORA_SERVICE@@',ora_db_service).replace('@@DB_ORA_PORT@@',str(ora_db_port))
	with open(rep_db_conf_file, 'w') as file:
		file.write(new_db_conf_file)
if (ora_schema_name == 'AU'):
	print("Doing for AUDIT")
	db_conf_file 		= open(rep_db_conf_file, 'r').read()
	new_db_conf_file 	= db_conf_file.replace('@@PG_USER@@',pg_au_schema).replace('@@PG_USER_PASSWD@@',pg_au_schema_passwd).replace('@@PG_DB_HOST@@',pg_db_gc_hostname).replace('@@PG_DB_SERVICE@@',pg_db_gc_database).replace('@@PG_DB_PORT@@',str(pg_db_gc_port)).replace('@@ORA_USER@@',ora_schema).replace('@@ORA_USER_PASSWD@@',ora_schema_passwd).replace('@@DB_ORA_HOST@@',ora_db_host).replace('@@DB_ORA_SERVICE@@',ora_db_service).replace('@@DB_ORA_PORT@@',str(ora_db_port))
	with open(rep_db_conf_file, 'w') as file:
		file.write(new_db_conf_file)
	
os.chdir(baseDir + os.sep + 'bin')
print (os.getcwd())
os.system("chmod -R 755 " + baseDir )
os.system("python3 pg_migrator.py " + ora_schema_name)