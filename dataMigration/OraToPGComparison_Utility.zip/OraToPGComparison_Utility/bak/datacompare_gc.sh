#!/bin/bash

export PATH=$JAVA_HOME/bin:$PATH

libpath=$MIGRATION_HOME/lib

for i in $libpath/*.jar; do
  CP=$i:$CP
done
start=$(date +%s)
filename=$MIGRATION_HOME/conf/tables_gc.conf
while read tablename; do
  if [ -z "$tablename" ]; then
    echo "got empty line"
    exit 1
  else
    echo "##################################################"
    echo $tablename
    case $tablename in
      FT_CFG_RSRC | FT_CFG_MSGP | FT_BE_BDEF | FT_LOG_LOGE | FT_WF_WFRV | FT_WF_WFDV | FT_T_WSUS | FT_WF_WFNP | FT_WF_WFTI | FT_O_NLPM | FT_T_VNRD)
        java -Xmx8G -cp $CP org.replicadb.compare.DBMatchData $MIGRATION_HOME/conf/replicadb.conf $tablename  4 100000 false partial false $MIGRATION_HOME/log/$csvfile # Arguments : <conf file path> <tablename> <threadpoolsize> <chunksize> <debugenabled{0|1} <matchtype{full|partial|rowcount}> <csv_file_path>
        ;;
      *)
        java -Xmx8G -cp $CP org.replicadb.compare.DBMatchData $MIGRATION_HOME/conf/replicadb.conf $tablename  4 100000 false partial false $MIGRATION_HOME/log/$csvfile # Arguments : <conf file path> <tablename> <threadpoolsize> <chunksize> <debugenabled{0|1} <matchtype{full|partial|rowcount}> <csv_file_path>
        ;;
    esac

    echo "##################################################"
    echo "                                                  "
  fi

done <$filename
end=$(date +%s)
echo Total time for all tables: $((end - start)) Secs
