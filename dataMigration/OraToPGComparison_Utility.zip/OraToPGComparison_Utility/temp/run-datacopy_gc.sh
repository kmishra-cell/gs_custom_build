#!/bin/bash

if [ -z $JAVA_HOME ]; then
  echo "JAVA_HOME is not set correctly, exit"
  exit;
fi
export MIGRATION_HOME=/home/OraToPGMigration_20220724
if [ -z $MIGRATION_HOME ]; then
  echo "MIGRATION_HOME is not set correctly - Set it to the installation directory ,exit"
  exit;
fi

current_time=$(date "+%Y.%m.%d-%H.%M.%S")
logfile=datacopy.$current_time.log
export csvfile=datacopy.$current_time.csv
touch $MIGRATION_HOME/log/$logfile

$MIGRATION_HOME/bin/datacopy_gc.sh >$MIGRATION_HOME/log/$logfile 2>&1
